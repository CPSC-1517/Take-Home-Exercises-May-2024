﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookSystem
{
    public class Review
    {
        private string _ISBN;
        private string _Title;
        private string _Author;
        private string _Reviewer;
        private string _Comment;

        public string ISBN
        {
            get { return _ISBN; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("ISBN is required");
                }
                _ISBN = value.Trim();
            }
        }
        public string Title
        {
            get { return _Title; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Title is required");
                }
                _Title = value.Trim();
            }
        }

        public string Author
        {
            get { return _Author; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Author is required");
                }
                _Author = value.Trim();
            }
        }

        public string Reviewer
        {
            get { return _Reviewer; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Reviewer is required");
                }
               _Reviewer = value;
            }
        }

        public RatingType Rating { get; set; }

        public string Comment
        {
            get { return _Comment; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Comment is required");
                }
                _Comment = value.Trim();
            }
        }

        public Review(string isbn, string title, string author, string reviewer, 
                        RatingType rating, string comment)
        {
            ISBN = isbn;
            Title = title;
            Author = author;
            Reviewer = reviewer;
            Rating = rating;
            Comment = comment;
        }
        public override string ToString()
        {
            return $"{ISBN},{Title},{Author},{Reviewer},{Rating},{Comment}";
        }
        public static Review Parse(string text)
        {
            string[] peices = text.Split(',');

            if (peices.Length != 6)
            {
                throw new FormatException($"String not in expeced format. Review: {text}");
            }
            return new Review(peices[0], peices[1], peices[2], peices[3],
                (RatingType)Enum.Parse(typeof(RatingType), peices[4]), peices[5]);
        }
       
    }
}
